Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_wisata-tobasa-de_DE.po
* app_wisata-tobasa-id_ID.po
* app_wisata-tobasa_ES.po
* app_wisata-tobasa-en_US.po
* app_wisata-tobasa-de_DE.mo
* app_wisata-tobasa-id_ID.mo
* app_wisata-tobasa-es_ES.mo
* app_wisata-tobasa-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
